import React from 'react';

const Home = () => {
  return (
    <div>
      <h1>Welcome to FX Syndicate</h1>
      <p>Compete. Trade. Win Big.</p>
    </div>
  );
};

export default Home;